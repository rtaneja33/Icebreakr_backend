"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
exports.SettingSchemaName = "settings";
const SettingSchema = new mongoose.Schema({
    key: {
        type: String,
        required: true
    },
    value: {
        type: Object,
        required: true
    }
});
exports.Setting = mongoose.model(exports.SettingSchemaName, SettingSchema);
