"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function serializeNotificationItemAdmin(model) {
    return {
        id: model.notification._id,
        content: model.notification.content,
        createdAt: model.createdAt,
        metadata: model.notification.metadata,
        expiryDate: model.notification.expiryDate
    };
}
exports.serializeNotificationItemAdmin = serializeNotificationItemAdmin;
