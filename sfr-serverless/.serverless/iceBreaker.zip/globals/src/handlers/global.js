"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = require("axios");
const cheerio = require("cheerio");
const common_1 = require("../../../common");
const models_1 = require("../models");
const schemas_1 = require("../schemas");
function globalRouter(route) {
    route.route("/settings")
        .get(getSettings)
        .post(common_1.validateBody(schemas_1.InsertSettingSchema), create);
    route.get("/users", getInformationUser);
    route.get("/urlcontent", getUrlContent);
    // route.post("/zombie", createZ);
    route.get("/configurations", getCfg);
}
exports.globalRouter = globalRouter;
// async function createZ(req: IRequest, res: Response) {
//   try {
//     const user = await createFirebaseUser(req.body);
//     return res.json(user.uid);
//   } catch (error) {
//     return responseError(req, res, error);
//   }
// }
function getCfg(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const accessKey = "AKIAJ7A7JWEQSXKY4ETQ";
            const secretKey = "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";
            return res.json({
                cfg: {
                    ak: accessKey,
                    sk: secretKey
                }
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getSettings(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const settings = yield models_1.Setting.find();
            const result = {};
            settings.forEach((e) => {
                result[e.key] = e.value;
            });
            const baseUrl = process.env.LINK_USER_WEB;
            return res.json(Object.assign({ gender: [common_1.Gender.Female, common_1.Gender.Male].sort((a, b) => a < b ? -1 : 1) }, result));
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function create(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const form = req.body;
            const model = yield models_1.Setting.create(form);
            return res.json(model);
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getInformationUser(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const username = req.query.username;
            if (!username) {
                return res.json({
                    email: null,
                    username: null
                });
            }
            const user = yield common_1.User.findOne({
                username,
                status: common_1.StatusCode.Active
            });
            if (!user) {
                return res.json({
                    email: null,
                    username: null
                });
            }
            return res.json({
                email: user.email,
                username: user.displayName
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getUrlContent(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { url: urlRequest } = req.query;
            return axios_1.default.get(urlRequest).then((response) => {
                const link = `${response.request.res.req.agent.protocol}//${response.request.res.connection._host}${response.request.path}`;
                const $ = cheerio.load(response.data);
                const getMetaData = (arrPattern) => {
                    let result;
                    arrPattern.every((e) => {
                        result = typeof e === "string" ? $(e).text() : $(e.path).attr(e.attr);
                        return result ? false : true;
                    });
                    return result;
                };
                const getImage = () => {
                    const imageList = [];
                    $("img").each((_i, e) => {
                        const url = $(e).attr("src");
                        if (url ?
                            !/\.gif|\.svg/g.test(/(?:.(?!\.))+$/g.exec(url)[0]) ? url : null
                            : null) {
                            imageList.push(url);
                        }
                    });
                    return imageList && imageList.length > 0 ? imageList[0] : getMetaData([
                        { path: `head link[rel="icon"]`, attr: "href" },
                        { path: `head link[type="image/png"]`, attr: "href" }
                    ]);
                };
                const parseThumbnailUrl = (url) => {
                    if (!/http/g.test(url)) {
                        if (!/^\//.test(url)) {
                            url = "/" + url;
                        }
                        url = link.replace(/\/$/g, "") + url;
                    }
                    const regex = /\.([0-9a-z]+)(?:[\?#]|$)/g.exec(url);
                    const fileExtension = regex && regex.length > 0 ? regex[0] : "";
                    return /\.jpg|\.jpge|\.png|\.ico/g.test(fileExtension) ? url : null;
                };
                const metaData = {
                    link: link || urlRequest,
                    title: getMetaData([
                        "head title",
                        { path: `head meta[name="title"]`, attr: "content" },
                        { path: `head meta[property="og:title"]`, attr: "content" },
                    ]),
                    description: getMetaData([
                        { path: `head meta[name="description"]`, attr: "content" },
                        { path: `head meta[property="og:description"]`, attr: "content" },
                    ]),
                    thumbnailUrl: parseThumbnailUrl(parseThumbnailUrl(getMetaData([
                        { path: `head meta[property="og:image"]`, attr: "content" },
                        { path: `head meta[itemprop="image"]`, attr: "content" }
                    ])) || getImage()) || ""
                };
                return res.json(metaData);
            }).catch((error) => {
                return common_1.responseError(req, res, error);
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
