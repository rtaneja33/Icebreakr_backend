"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("../../../common");
const notification_1 = require("../schemas/notification");
const notification_2 = require("../serializers/notification");
function adminRouter(route) {
    route.route("/notifications")
        .post(common_1.validateBody(notification_1.PushNotificationSchema), pushBroadcast)
        .get(listBroadcast);
}
exports.adminRouter = adminRouter;
function pushBroadcast(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const form = req.body;
            const currentUserId = req.context.currentUser._id;
            const keyBroadcast = "role";
            const dataPush = {
                title: form.title,
                content: form.content,
                tags: form.type.map((e) => ({ key: keyBroadcast, value: e })),
                senderId: currentUserId,
                type: common_1.ReferenceType.Broadcast,
                expiryDate: form.expiryDate
            };
            yield common_1.pushNotificationBroadcast(null, dataPush, {
                actorId: req.context.currentUser._id
            });
            return res.json({
                message: "Push broadcast notification successfully"
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function listBroadcast(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const notificationUser = yield common_1.filterPagination(common_1.NotificationUser, {
                $or: [
                    { typeRole: { $all: [""] } },
                    { typeRole: { $all: [""] } }
                ]
            }, Object.assign({}, req.query, { sort: { createdAt: -1 } }));
            if (notificationUser.data.length > 0) {
                let notifications = yield common_1.Notification.find({ _id: { $in: notificationUser.data.map((e) => e.notificationId) } });
                const users = yield common_1.User.find({ _id: { $in: notifications.map((e) => e.senderId) } });
                notifications = notifications.map((e) => (Object.assign({}, e.toJSON(), { sender: users.find((u) => u._id.toString() === e.senderId.toString()).toJSON() })));
                notificationUser.data = notificationUser.data.map((e) => (Object.assign({}, e.toJSON(), { notification: notifications.find((n) => n._id.toString() === e.notificationId.toString()) }))).map(notification_2.serializeNotificationItemAdmin);
            }
            return res.json(notificationUser);
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
