"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BaseJoi = require("joi");
const JoiDateExtension = require("joi-date-extensions");
const common_1 = require("../../../common");
const Joi = BaseJoi.extend(JoiDateExtension);
exports.PushNotificationSchema = Joi.object({
    title: Joi.string().required(),
    content: Joi.string().required(),
    type: Joi.array().items(Joi.string().required().valid(["", ""])).min(1).required(),
    expiryDate: Joi.date().format(common_1.DEFAULT_DATE_FORMAT)
});
