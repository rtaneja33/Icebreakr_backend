"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Joi = require("joi");
exports.InsertSettingSchema = Joi.object({
    key: Joi.string().required(),
    value: Joi.string().required()
});
