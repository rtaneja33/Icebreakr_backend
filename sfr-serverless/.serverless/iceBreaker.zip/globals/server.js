"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// init app
const serverless_1 = require("../common/services/serverless");
const src_1 = require("./src");
exports.handler = serverless_1.serverlessHandler(src_1.app);
