"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const user_1 = require("./user");
const router = express_1.Router();
exports.router = router;
user_1.userRouter(router);
