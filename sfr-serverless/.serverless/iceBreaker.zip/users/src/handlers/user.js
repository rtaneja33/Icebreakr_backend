"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const AWS = require("aws-sdk");
const common_1 = require("../../../common");
const business_1 = require("../business");
const models_1 = require("../models");
const serializers_1 = require("../serializers");
const user_friends_1 = require("../models/user-friends");
const fileType = require('file-type');
function userRouter(route) {
    route.route("/me")
        .get(common_1.validateHeader(common_1.HeaderAuthorizationSchema, {
        allowUnknown: true
    }), getProfile)
        .put(
    // validateHeader(HeaderAuthorizationSchema, {
    //   allowUnknown: true
    // }),
    // validateBody(UpdateUserSchema, {
    //   allowUnknown: true
    // }),
    updateProfile);
    route.get("/me/getMyData", getMyData);
    route.get("/users/getUserProfile/:userId", getUserProfile);
    route.post("/me/sendFriendRequest/:userId", sendFriendRequest);
    route.post("/me/respondToFriendRequest", respondToFriendRequest);
    route.post("/me/getFriends", getFriends);
    route.post("/me/removeFromFriends/:userId", removeFromFriends);
    route.post("/me/getNearbyUsers", getNearbyUsers);
    route.post("/me/getSuggestionContacts", getSuggestionContacts);
    route.get("/me/notifications", getMyNotification);
    route.post("/me/readMyNotification/:id", readMyNotification);
    route.post("/me/markAllNotificationsRead", markAllNotificationsRead);
    route.post("/me/logUserActivity", logUserActivity);
    route.post("/me/updateLocation", updateLocation);
    route.post("/me/sendMessage", sendMessage);
    route.get("/me/getMySentMessages", getMySentMessages);
    route.get("/me/getMessagesSentToMe", getMessagesSentToMe);
    route.get("/me/getAllMyMessages", getAllMyMessages);
    route.get("/me/getAllUsers", getAllUsers);
    route.post("/me/uploadProfileImage", uploadProfileImage);
}
exports.userRouter = userRouter;
function uploadProfileImage(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            AWS.config.setPromisesDependency(require('bluebird'));
            AWS.config.update({
                accessKeyId: 'AKIAJ7A7JWEQSXKY4ETQ',
                secretAccessKey: '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',
                region: 'us-east-1'
            });
            const s3 = new AWS.S3();
            let base64String = req.body.base64String;
            // pass the base64 string into a buffer
            let buffer = new Buffer(base64String, 'base64');
            let fileMime = fileType(buffer);
            // check if the base64 encoded string is a file
            if (fileMime === null) {
                console.log('The string supplied is not a file type');
            }
            let file = getFile(fileMime, buffer);
            let params = file.params;
            console.log("params: ", params);
            let location = '';
            let key = '';
            const { Location, Key } = yield s3.upload(params).promise();
            location = Location;
            key = Key;
            console.log(location, key);
            return res.json({
                filePath: location
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getFile(fileMime, buffer) {
    // get the file extension
    let fileExt = fileMime.ext;
    //  let now = moment().format('YYYY-MM-DD HH:mm:ss');
    let fileName = Date.now() + '.' + fileExt;
    let params = {
        Bucket: "icebreaker-dev-images",
        Key: "images/" + fileName,
        // 'this is simply the filename and the extension, e.g fileFullName + fileExt',
        Body: buffer,
        ContentType: fileMime.mime,
        ContentEncoding: 'base64',
    };
    let uploadFile = {
        size: buffer.toString('ascii').length,
        type: fileMime.mime,
        name: fileName
        //  full_path: fileFullPath
    };
    return {
        'params': params,
        'uploadFile': uploadFile
    };
}
function getAllUsers(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            let currentUser = yield common_1.User.findById(currentUserId);
            const modelFilter = {
                status: common_1.StatusCode.Active,
                _id: {
                    $nin: [currentUser._id]
                }
            };
            var METERS_PER_MILE = Number(process.env.METERS_PER_MILE);
            var defaultDistance = Number(process.env.DEFAULT_DISTANCE);
            if (currentUser.searchRadius != null) {
                defaultDistance = currentUser.searchRadius;
            }
            var locationField = {
                $geoNear: {
                    near: { type: "Point", coordinates: currentUser.location.coordinates },
                    distanceField: "calcDistance",
                    distanceMultiplier: 0.000621371,
                    maxDistance: defaultDistance * METERS_PER_MILE
                }
            };
            const models = yield common_1.filterPagination(common_1.User, modelFilter, Object.assign({}, req.query, { sort: { calcDistance: 1 }, needParse: false, buildQuery: (query, limit, skip) => {
                    let queryBase;
                    queryBase = query.aggregate([
                        locationField,
                        { $match: modelFilter },
                        { $sort: { calcDistance: 1 } }
                    ]);
                    console.log("query base is: ", queryBase);
                    return queryBase.skip(skip).limit(limit);
                } }));
            if (models.data != null && models.data.length > 0) {
                const friendIdList = yield business_1.getFriendIdStringList(currentUserId);
                const mySentRequests = yield business_1.mySentFriendRequests(currentUserId);
                const receivedRequests = yield business_1.hasSentMeFriendRequests(currentUserId);
                models.data = yield business_1.parseProfiles(models.data);
                // models.data = await parseBlock(currentUserId, models.data);
                for (var k = 0; k < models.data.length; k++) {
                    var data = models.data[k];
                    data.isMyFriend = friendIdList.length > 0 && friendIdList.includes(data._id.toString());
                    data.friendRequestSent = mySentRequests.length > 0 && mySentRequests.includes(data._id.toString());
                    data.friendRequestReceived = receivedRequests.length > 0 && receivedRequests.includes(data._id.toString());
                }
            }
            return res.json({
                data: models.data.map(serializers_1.serializerUser),
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function sendMessage(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const chatForm = req.body;
            chatForm.createdBy = currentUserId;
            const chat = yield models_1.UserChat.create(chatForm);
            return res.json({
                message: "Message sent successfully!!!!",
                data: chat
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getMySentMessages(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const modelFilter = {
                createdBy: mongoose.Types.ObjectId(currentUserId)
            };
            const models = yield common_1.filterPagination(models_1.UserChat, modelFilter, Object.assign({}, req.query, { sort: { createdAt: -1 }, needParse: false, buildQuery: (query, limit, skip) => {
                    console.log("Model Filter: ", modelFilter);
                    var queryBase = query.aggregate([
                        { $match: modelFilter },
                        { $sort: { createdAt: -1 } }
                    ]);
                    console.log("query base is: ", queryBase);
                    return queryBase.skip(skip).limit(limit);
                } }));
            return res.json({
                data: models.data,
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getMessagesSentToMe(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const modelFilter = {
                toUserId: mongoose.Types.ObjectId(currentUserId)
            };
            const models = yield common_1.filterPagination(models_1.UserChat, modelFilter, Object.assign({}, req.query, { sort: { createdAt: -1 }, needParse: false, buildQuery: (query, limit, skip) => {
                    console.log("Model Filter: ", modelFilter);
                    var queryBase = query.aggregate([
                        { $match: modelFilter },
                        { $sort: { createdAt: -1 } }
                    ]);
                    console.log("query base is: ", queryBase);
                    return queryBase.skip(skip).limit(limit);
                } }));
            return res.json({
                data: models.data,
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getAllMyMessages(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const modelFilter = {
                $or: [
                    { toUserId: mongoose.Types.ObjectId(currentUserId) },
                    { createdBy: mongoose.Types.ObjectId(currentUserId) }
                ]
            };
            const models = yield common_1.filterPagination(models_1.UserChat, modelFilter, Object.assign({}, req.query, { sort: { createdAt: -1 }, needParse: false, buildQuery: (query, limit, skip) => {
                    console.log("Model Filter: ", modelFilter);
                    var queryBase = query.aggregate([
                        { $match: modelFilter },
                        { $sort: { createdAt: -1 } }
                    ]);
                    console.log("query base is: ", queryBase);
                    return queryBase.skip(skip).limit(limit);
                } }));
            return res.json({
                data: models.data,
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function updateLocation(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const coordinates = req.body.coordinates;
            let newLocation = {
                type: common_1.LocationType.POINT,
                coordinates: coordinates
            };
            const locationForm = {
                referenceId: currentUserId,
                location: newLocation
            };
            const createdLocation = yield common_1.UserLocation.create(locationForm);
            console.log("Created location: ", createdLocation);
            let user = yield common_1.User.findByIdAndUpdate(currentUserId, { location: newLocation }, { new: true });
            let parsedUser = yield business_1.parseUserProfile(user);
            return res.json({
                message: "Location updated successfully!!!",
                data: serializers_1.serializerUser(parsedUser)
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function logUserActivity(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const accountForm = req.body;
            accountForm.affectedUser = currentUserId;
            accountForm.createdBy = currentUserId;
            console.log("Account activity form: ", accountForm);
            const activity = yield common_1.AccountActivity.create(accountForm);
            return res.json({
                message: "Activity logged successfully!!!!",
                activity: activity
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function readMyNotification(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const notificationId = req.params.id;
            const currentUserId = req.context.currentUser._id;
            let notification = yield common_1.NotificationUser.findOne({ notificationId: notificationId, userId: currentUserId });
            if (notification != null) {
                notification = yield common_1.NotificationUser.findByIdAndUpdate(notification._id, { isRead: true, updatedBy: currentUserId }, { new: true });
                console.log("notification updated: ", notification);
                return res.json({
                    message: "Notifications read successfully!!",
                    notification: notification
                });
            }
            return res.json(business_1.emptyJson());
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getMyNotification(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const createdAt = (yield common_1.User.findById(currentUserId)).createdAt;
            const modelFilter = {
                isRead: false,
                $or: [
                    { userId: mongoose.Types.ObjectId(currentUserId) },
                    { typeRole: { $all: [req.context.currentUser.role] } },
                ],
                createdAt: { $gte: createdAt }
            };
            console.log("Model Filter: ", modelFilter);
            const models = yield common_1.filterPagination(common_1.NotificationUser, modelFilter, Object.assign({}, req.query, { sort: { createdAt: -1 }, buildQuery: (query, limit, skip) => {
                    const lookupNotification = {
                        $lookup: {
                            from: common_1.NotificationSchemaName,
                            localField: "notificationId",
                            foreignField: "_id",
                            as: "notification"
                        }
                    };
                    return query.aggregate([
                        { $match: modelFilter },
                        lookupNotification,
                        { $sort: { createdAt: -1 } }
                    ].filter(e => e)).skip(skip).limit(limit);
                } }));
            console.log("Notific data: ", models.data);
            if (models.data != null && models.data.length > 0) {
                const notifcIds = models.data.map((e) => e._id);
                console.log("notifcIds: ", notifcIds);
                const viewedNotifications = yield common_1.NotificationUser.updateMany({ _id: { $in: notifcIds } }, { $set: { isViewed: true } });
                console.log("Viewed Notifications: ", viewedNotifications);
            }
            return res.json({
                data: (yield business_1.parseMyNotification(models.data.map((e) => e.notificationId), {
                    actorId: req.context.currentUser._id
                })).map(serializers_1.serializerNotificationItem),
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function markAllNotificationsRead(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            let notifications = yield common_1.NotificationUser.find({ userId: currentUserId });
            if (notifications != null) {
                const notificationIds = notifications.map((e) => e._id);
                console.log("Notification Ids: ", notificationIds);
                let readNotifications = yield common_1.NotificationUser.updateMany({ _id: { $in: notificationIds } }, { $set: { isRead: true } });
                console.log("notifications: ", readNotifications);
                return res.json({
                    // data: (await parseMyNotification(notifications.map((e) => e.notificationId), {
                    //   actorId: req.context.currentUser._id
                    // })).map(serializerNotificationItem)
                    message: "All notifications read successfully!!"
                    // data: notifications
                });
            }
            return res.json(business_1.emptyJson());
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getNearbyUsers(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            let currentUser = yield common_1.User.findById(currentUserId);
            let isCoordinatesSame = false;
            console.log("req coordinates: ", req.body.coordinates);
            console.log(req.body != null && req.body.coordinates != null);
            let locationField;
            var METERS_PER_MILE = Number(process.env.METERS_PER_MILE);
            var defaultDistance = Number(process.env.DEFAULT_DISTANCE);
            if (currentUser.searchRadius != null) {
                defaultDistance = currentUser.searchRadius;
            }
            console.log("defaultDistance: ", defaultDistance);
            console.log("METERS_PER_MILE: ", METERS_PER_MILE);
            if (req.body != null && req.body.coordinates != null) {
                let locCoordinates = req.body.coordinates;
                if (currentUser.location != null
                    && currentUser.location.coordinates != null && currentUser.location.coordinates.length > 0) {
                    const userCoordinates = currentUser.location.coordinates;
                    if (locCoordinates[0] === userCoordinates[0] && locCoordinates[1] === userCoordinates[1]) {
                        isCoordinatesSame = true;
                    }
                    console.log("userCoordinates: ", userCoordinates);
                }
                console.log("locCoordinates: ", locCoordinates);
                console.log("isCoordinatesSame: ", isCoordinatesSame);
                if (!isCoordinatesSame) {
                    const newLocation = {
                        type: common_1.LocationType.POINT,
                        coordinates: locCoordinates
                    };
                    const userLocationForm = {
                        referenceId: currentUserId,
                        location: newLocation,
                        createdBy: currentUserId
                    };
                    console.log("Form is: ", userLocationForm);
                    let locationUpdated = yield common_1.UserLocation.create(userLocationForm);
                    console.log("Updated location: ", locationUpdated);
                    currentUser = yield common_1.User.findByIdAndUpdate(currentUserId, { location: newLocation }, { new: true });
                }
                locationField = {
                    $geoNear: {
                        near: { type: "Point", coordinates: currentUser.location.coordinates },
                        distanceField: "calcDistance",
                        distanceMultiplier: 0.000621371,
                        maxDistance: defaultDistance * METERS_PER_MILE
                    }
                };
            }
            console.log("location field: ", locationField);
            var modelFilter = {
                status: common_1.StatusCode.Active,
                _id: {
                    $nin: [currentUser._id]
                }
            };
            const query = req.query;
            console.log("request Query: ", query);
            if (query != null && query.hasOwnProperty('name') && query.name != ''.trim()) {
                const searchString = query.name.toString().toLowerCase();
                console.log("Search: ", query.name);
                console.log('String: ', searchString);
                modelFilter = {
                    $and: [
                        { status: common_1.StatusCode.Active },
                        { _id: {
                                $nin: [currentUser._id]
                            }
                        },
                        {
                            $or: [
                                { displayName: new RegExp(searchString, "i") },
                                { companyName: new RegExp(searchString, "i") }
                            ]
                        }
                    ]
                };
            }
            else if (query != null && query.hasOwnProperty('searchParams') && query.searchParams === 'location') {
                console.log("search coordinates: ", req.body.searchCoordinates.length);
                if (req.body.searchCoordinates != null && req.body.searchCoordinates.length == 2) {
                    locationField = {
                        $geoNear: {
                            near: { type: "Point", coordinates: req.body.searchCoordinates },
                            distanceField: "calcDistance",
                            distanceMultiplier: 0.000621371,
                            maxDistance: defaultDistance * METERS_PER_MILE
                        }
                    };
                }
                else {
                    return common_1.responseError(req, res, common_1.ErrorKey.SearchCoordinatesNeeded);
                }
            }
            console.log("Model Filter: ", modelFilter);
            const models = yield common_1.filterPagination(common_1.User, modelFilter, Object.assign({}, req.query, { sort: { calcDistance: 1 }, needParse: false, buildQuery: (query, limit, skip) => {
                    let queryBase;
                    queryBase = query.aggregate([
                        locationField,
                        { $match: modelFilter },
                        { $sort: { calcDistance: 1 } }
                    ]);
                    console.log("query base is: ", queryBase);
                    return queryBase.skip(skip).limit(limit);
                } }));
            if (models.data != null && models.data.length > 0) {
                const friendIdList = yield business_1.getFriendIdStringList(currentUserId);
                const mySentRequests = yield business_1.mySentFriendRequests(currentUserId);
                const receivedRequests = yield business_1.hasSentMeFriendRequests(currentUserId);
                models.data = yield business_1.parseProfiles(models.data);
                // models.data = await parseBlock(currentUserId, models.data);
                for (var k = 0; k < models.data.length; k++) {
                    var data = models.data[k];
                    data.isMyFriend = friendIdList.length > 0 && friendIdList.includes(data._id.toString());
                    data.friendRequestSent = mySentRequests.length > 0 && mySentRequests.includes(data._id.toString());
                    data.friendRequestReceived = receivedRequests.length > 0 && receivedRequests.includes(data._id.toString());
                }
            }
            return res.json({
                data: models.data.map(serializers_1.serializerUser),
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getMyData(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return res.json({
                data: "This is test data"
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getSuggestionContacts(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const currentUser = yield common_1.User.findById(currentUserId);
            const myFriends = yield business_1.getMyFriendUserIdList(currentUserId);
            let notTobeIncludedList = [currentUser._id];
            if (myFriends != null && myFriends.length > 0) {
                notTobeIncludedList.push(...myFriends);
            }
            console.log("notTobeIncludedList: ", notTobeIncludedList);
            let modelFilter = {
                status: common_1.StatusCode.Active
            };
            let locationField = null;
            var METERS_PER_MILE = Number(process.env.METERS_PER_MILE);
            var defaultDistance = Number(process.env.DEFAULT_DISTANCE);
            if (currentUser.searchRadius != null) {
                defaultDistance = currentUser.searchRadius;
            }
            const query = req.query;
            if (query != null && query.hasOwnProperty('name') && query.name != ''.trim()) {
                const searchString = query.name.toString().toLowerCase();
                console.log("Search: ", query.name);
                console.log('String: ', searchString);
                // modelFilter.displayName = new RegExp(searchString, "i");
                modelFilter = {
                    $and: [
                        { status: common_1.StatusCode.Active },
                        {
                            $or: [
                                { displayName: new RegExp(searchString, "i") },
                                { companyName: new RegExp(searchString, "i") }
                            ]
                        }
                    ]
                };
            }
            else if (query != null && query.hasOwnProperty('searchParams') && query.searchParams === 'location') {
                console.log("search coordinates: ", req.body.searchCoordinates.length);
                if (req.body.searchCoordinates != null && req.body.searchCoordinates.length == 2) {
                    locationField = {
                        $geoNear: {
                            near: { type: "Point", coordinates: req.body.searchCoordinates },
                            distanceField: "calcDistance",
                            distanceMultiplier: 0.000621371,
                            maxDistance: defaultDistance * METERS_PER_MILE
                        }
                    };
                }
                else {
                    return Promise.reject(common_1.ErrorKey.SearchCoordinatesNeeded);
                }
            }
            console.log("Model Filter: ", modelFilter);
            const models = yield common_1.filterPagination(common_1.User, modelFilter, Object.assign({}, req.query, { sort: { displayName: 1 }, needParse: false, buildQuery: (query, limit, skip) => {
                    modelFilter._id = {
                        $nin: notTobeIncludedList
                    };
                    console.log("Model Filter: ", modelFilter);
                    var queryBase = query.aggregate([
                        { $match: modelFilter },
                        { $sort: { displayName: 1 } }
                    ]);
                    if (locationField != null) {
                        queryBase = query.aggregate([
                            locationField,
                            { $match: modelFilter },
                            { $sort: { displayName: 1 } }
                        ]);
                    }
                    console.log("query base is: ", queryBase);
                    return queryBase.skip(skip).limit(limit);
                } }));
            console.log("Users: ", models);
            if (models.data != null && models.data.length > 0) {
                const friendIdList = yield business_1.getFriendIdStringList(currentUserId);
                const mySentRequests = yield business_1.mySentFriendRequests(currentUserId);
                const receivedRequests = yield business_1.hasSentMeFriendRequests(currentUserId);
                models.data = yield business_1.parseProfiles(models.data);
                // models.data = await parseBlock(currentUserId, models.data);
                for (var k = 0; k < models.data.length; k++) {
                    var data = models.data[k];
                    data.isMyFriend = friendIdList.length > 0 && friendIdList.includes(data._id.toString());
                    data.friendRequestSent = mySentRequests.length > 0 && mySentRequests.includes(data._id.toString());
                    data.friendRequestReceived = receivedRequests.length > 0 && receivedRequests.includes(data._id.toString());
                }
            }
            return res.json({
                data: models.data.map(serializers_1.serializerUser),
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
exports.getSuggestionContacts = getSuggestionContacts;
function getUserProfile(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const userId = req.params.userId;
            const user = yield common_1.User.findById(mongoose.Types.ObjectId(userId));
            if (!user) {
                return common_1.responseError(req, res, common_1.ErrorKey.ProfileNotFound, {
                    statusCode: 404
                });
            }
            const [result] = yield business_1.parseProfiles([user]);
            return res.json({
                data: serializers_1.serializerUser(result)
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
exports.getUserProfile = getUserProfile;
function getProfile(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const token = req.headers.authorization;
            console.log("Token received: ", token);
            //const token = req.body.authToken;
            const authId = yield common_1.verifyFirebaseToken(token);
            //const authId = req.body.authToken;
            const user = yield common_1.User.findOne({
                authId: authId
            });
            if (!user) {
                return common_1.responseError(req, res, common_1.ErrorKey.ProfileNotFound, {
                    statusCode: 404
                });
            }
            const [result] = yield business_1.parseProfiles([user]);
            return res.json({
                data: serializers_1.serializerUser(result)
            });
        }
        catch (error) {
            console.log("Error Get Profile", error);
            return common_1.responseError(req, res, common_1.ErrorKey.Unauthorized, {
                statusCode: 401
            });
        }
    });
}
exports.getProfile = getProfile;
function updateProfile(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("Update profile");
        try {
            const token = req.headers.authorization;
            console.log("Token received: ", token);
            console.log("request body: ", req.body);
            const form = req.body;
            if (form.permissions) {
                delete form.permissions;
            }
            if (form.coordinates) {
                let newLocation = {
                    type: common_1.LocationType.POINT,
                    coordinates: form.coordinates
                };
                form.location = newLocation;
            }
            //const authId = req.body.authId;
            const authId = yield common_1.verifyFirebaseToken(token);
            console.log("AUth ID is : ", authId);
            const user = yield common_1.User.findOne({ authId: authId });
            console.log("Is user: ", user);
            let modelUpdated;
            if (user) {
                modelUpdated = yield common_1.User.findByIdAndUpdate(user._id, form, {
                    new: true
                });
            }
            else {
                console.log("Form is : ", form);
                form.authId = authId;
                console.log("Updated form: ", form);
                const [checkPhone, checkAuthIdExisted] = yield Promise.all([
                    common_1.User.findOne({
                        phone: form.phone,
                        status: common_1.StatusCode.Active
                    }),
                    common_1.User.findOne({
                        authId: authId
                    })
                ]);
                if (checkPhone) {
                    return common_1.responseError(req, res, common_1.ErrorKey.PhoneExisted);
                }
                if (checkAuthIdExisted) {
                    return common_1.responseError(req, res, common_1.ErrorKey.AuthExisted);
                }
                console.log("Unique user");
                try {
                    console.log("Creating user");
                    modelUpdated = yield common_1.User.create(form);
                    console.log("user created");
                }
                catch (error) {
                    if (error && error.code === 11000 && /phone/g.test(error.errmsg)) {
                        return common_1.responseError(req, res, common_1.ErrorKey.PhoneExisted, {
                            statusCode: 404
                        });
                    }
                    return common_1.responseError(req, res, error);
                }
            }
            const [result] = yield business_1.parseProfiles([modelUpdated]);
            return res.json(serializers_1.serializerUser(result));
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function sendFriendRequest(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const friendUserId = req.params.userId;
            const currentUserId = req.context.currentUser._id;
            const friendUser = yield common_1.User.findById(friendUserId);
            const friendForm = {
                userId: currentUserId,
                friendUserId: friendUser._id,
                requestStatus: common_1.FriendRequestStatus.Sent,
                requestSendDate: new Date(),
                createdBy: currentUserId
            };
            yield user_friends_1.UserFriend.create(friendForm);
            const notify = yield common_1.createAndPushNotificationWithFormat(null, Object.assign({}, common_1.getContentNotification(common_1.NotificationKeyType.SentFriendRequest), { senderId: currentUserId, receiverIds: [friendUserId], type: common_1.ReferenceType.User, referenceId: currentUserId }), {
                actorId: currentUserId
            });
            const parsedFriend = yield business_1.parseUserProfile(friendUser);
            parsedFriend.friendRequestSent = true;
            console.log("Sent Notification: ", notify);
            return res.json({
                message: "Friend request sent successfully!!!",
                data: serializers_1.serializerUser(parsedFriend)
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function respondToFriendRequest(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const friendUserId = req.query.friendUserId;
            const friendResponse = req.query.friendResponse;
            let currentUserId = req.context.currentUser._id;
            var friendRequestStatus = "";
            let currentUser = yield common_1.User.findById(currentUserId);
            const form = {
                userId: mongoose.Types.ObjectId(friendUserId),
                friendUserId: currentUser._id,
                requestStatus: common_1.FriendRequestStatus.Sent
            };
            let parsedFriend;
            const friendRequest = yield user_friends_1.UserFriend.findOne(form);
            let friendUser = yield common_1.User.findById(friendUserId);
            parsedFriend = yield business_1.parseUserProfile(friendUser);
            console.log("Parsed Friend: ", parsedFriend);
            if (friendRequest != null) {
                if (friendResponse === common_1.FriendRequestStatus.Accepted) {
                    const updatedRequest = yield user_friends_1.UserFriend.findByIdAndUpdate(friendRequest._id, {
                        requestStatus: common_1.FriendRequestStatus.Accepted,
                        requestApprovedDate: new Date(),
                        updatedBy: currentUserId
                    }, { new: true });
                    console.log("Updated Request: ", updatedRequest);
                    friendRequestStatus = common_1.FriendRequestStatus.Accepted;
                    if (friendUser.status === common_1.StatusCode.Active) {
                        var friendUserFriends = friendUser.numFriends;
                        console.log("friendUserFriends: ", friendUserFriends);
                        if (null == friendUserFriends || typeof friendUserFriends === 'undefined') {
                            friendUserFriends = 0;
                        }
                        friendUserFriends = friendUserFriends + 1;
                        friendUser = yield common_1.User.findByIdAndUpdate(friendUser._id, { numFriends: friendUserFriends });
                        console.log("Updated Friend: ", friendUser);
                        var myFriendsCount = currentUser.numFriends;
                        console.log("myFriendsCount: ", myFriendsCount);
                        if (myFriendsCount == null || typeof myFriendsCount === 'undefined') {
                            myFriendsCount = 0;
                        }
                        myFriendsCount = myFriendsCount + 1;
                        parsedFriend.isMyFriend = true;
                        currentUser = yield common_1.User.findByIdAndUpdate(currentUserId, { numFriends: myFriendsCount });
                        console.log("My Profile: ", currentUser);
                        const notify = yield common_1.createAndPushNotificationWithFormat(null, Object.assign({}, common_1.getContentNotification(common_1.NotificationKeyType.AcceptedFriendRequest), { senderId: currentUserId, receiverIds: [friendUser._id], type: common_1.ReferenceType.User, referenceId: currentUserId }), {
                            actorId: currentUserId
                        });
                        console.log("Notification sent is: ", notify);
                    }
                }
                else if (friendResponse === common_1.FriendRequestStatus.Declined) {
                    const updatedRequest = yield user_friends_1.UserFriend.findByIdAndUpdate(friendRequest._id, {
                        requestStatus: common_1.FriendRequestStatus.Declined,
                        requestApprovedDate: new Date(),
                        updatedBy: currentUserId
                    }, { new: true });
                    console.log("Updated Request: ", updatedRequest);
                    friendRequestStatus = common_1.FriendRequestStatus.Declined;
                    parsedFriend.isMyFriend = false;
                }
                if (req.body.hasOwnProperty('notificationId')) {
                    const notificationId = req.body.notificationId;
                    let notification = yield common_1.NotificationUser.findOne({ notificationId: notificationId, userId: currentUserId });
                    notification = yield common_1.NotificationUser.findByIdAndUpdate(notification._id, { isRead: true }, { new: true });
                    console.log("Notification updated: ", notification);
                }
            }
            else {
                return common_1.responseError(req, res, common_1.ErrorKey.InvalidFriendRequest);
            }
            return res.json({
                message: "Friend Request " + friendRequestStatus + " Successfully!!!!",
                data: parsedFriend
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getFriends(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            const models = yield getFriendsData(currentUserId, req);
            console.log("Users: ", models);
            if (models.data.length > 0) {
                models.data = yield business_1.parseProfiles(models.data);
            }
            return res.json({
                data: models.data.map(serializers_1.serializerUser),
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function removeFromFriends(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentUserId = req.context.currentUser._id;
            console.log("Current user Id: ", currentUserId);
            const currentUser = yield common_1.User.findById(currentUserId);
            const friendUserId = req.params.userId;
            const friendUser = yield common_1.User.findById(friendUserId);
            const myForm = {
                status: common_1.StatusCode.Active,
                userId: friendUserId,
                friendUserId: currentUser._id,
                requestStatus: common_1.FriendRequestStatus.Accepted
            };
            const myFriendForm = {
                status: common_1.StatusCode.Active,
                userId: currentUser._id,
                friendUserId: friendUser._id,
                requestStatus: common_1.FriendRequestStatus.Accepted
            };
            console.log("Myform:", myForm);
            console.log("friendForm: ", myFriendForm);
            const myRequest = yield user_friends_1.UserFriend.findOne(myForm);
            console.log("My Requests: ", myRequest);
            if (myRequest != null) {
                console.log("my Request: ", myRequest);
                let myUpdatedRequest = yield user_friends_1.UserFriend.findByIdAndUpdate(myRequest._id, {
                    status: common_1.StatusCode.Deleted,
                    updatedBy: currentUserId,
                    updatedAt: new Date()
                }, { new: true });
                console.log("myUpdatedRequest: ", myUpdatedRequest);
            }
            else {
                const friendRequest = yield user_friends_1.UserFriend.findOne(myFriendForm);
                console.log("friendRequests: ", friendRequest);
                if (friendRequest != null) {
                    let myFriendUpdatedRequest = yield user_friends_1.UserFriend.findByIdAndUpdate(friendRequest._id, {
                        status: common_1.StatusCode.Deleted,
                        updatedBy: currentUserId,
                        updatedAt: new Date()
                    }, { new: true });
                    console.log("myFriendUpdatedRequest: ", myFriendUpdatedRequest);
                }
                else {
                    return common_1.responseError(req, res, common_1.ErrorKey.NotAFriend);
                }
            }
            if (friendUser.status === common_1.StatusCode.Active) {
                var friendUserFriends = friendUser.numFriends;
                console.log("friendUserFriends: ", friendUserFriends);
                if (null != friendUserFriends && friendUserFriends > 0) {
                    friendUserFriends = friendUserFriends - 1;
                }
                const updatedFriend = yield common_1.User.findByIdAndUpdate(friendUser._id, { numFriends: friendUserFriends });
                console.log("Updated Friends: ", updatedFriend);
                const currentUser = yield common_1.User.findById(currentUserId);
                var myFriendsCount = currentUser.numFriends;
                console.log("myFriendsCount: ", myFriendsCount);
                if (myFriendsCount != null && myFriendsCount > 0) {
                    myFriendsCount = myFriendsCount - 1;
                }
                const myProfile = yield common_1.User.findByIdAndUpdate(currentUserId, { numFriends: myFriendsCount });
                console.log("My Profile: ", myProfile);
            }
            let models = yield getFriendsData(currentUserId, req);
            if (models.data != null && models.data.length > 0) {
                models.data = yield business_1.parseProfiles(models.data);
            }
            return res.json({
                message: "Removed from my friend list successfully!!!",
                data: models.data.map(serializers_1.serializerUser),
                pagination: models.pagination
            });
        }
        catch (error) {
            return common_1.responseError(req, res, error);
        }
    });
}
function getFriendsData(userId, req) {
    return __awaiter(this, void 0, void 0, function* () {
        const myFriends = yield business_1.getMyFriendUserIdList(userId);
        const currentUser = yield common_1.User.findById(userId);
        let modelFilter = {
            status: common_1.StatusCode.Active
        };
        let locationField = null;
        var METERS_PER_MILE = Number(process.env.METERS_PER_MILE);
        var defaultDistance = Number(process.env.DEFAULT_DISTANCE);
        if (currentUser.searchRadius != null) {
            defaultDistance = currentUser.searchRadius;
        }
        const query = req.query;
        if (query != null && query.hasOwnProperty('name') && query.name != ''.trim()) {
            const searchString = query.name.toString().toLowerCase();
            console.log("Search: ", query.name);
            console.log('String: ', searchString);
            // modelFilter.displayName = new RegExp(searchString, "i");
            modelFilter = {
                $and: [
                    { status: common_1.StatusCode.Active },
                    {
                        $or: [
                            { displayName: new RegExp(searchString, "i") },
                            { companyName: new RegExp(searchString, "i") }
                        ]
                    }
                ]
            };
        }
        else if (query != null && query.hasOwnProperty('searchParams') && query.searchParams === 'location') {
            console.log("search coordinates: ", req.body.searchCoordinates.length);
            if (req.body.searchCoordinates != null && req.body.searchCoordinates.length == 2) {
                locationField = {
                    $geoNear: {
                        near: { type: "Point", coordinates: req.body.searchCoordinates },
                        distanceField: "calcDistance",
                        distanceMultiplier: 0.000621371,
                        maxDistance: defaultDistance * METERS_PER_MILE
                    }
                };
            }
            else {
                return Promise.reject(common_1.ErrorKey.SearchCoordinatesNeeded);
            }
        }
        console.log("Model Filter: ", modelFilter);
        const models = yield common_1.filterPagination(common_1.User, modelFilter, Object.assign({}, req.query, { sort: { displayName: 1 }, needParse: false, buildQuery: (query, limit, skip) => {
                modelFilter._id = {
                    $in: myFriends
                };
                console.log("Model Filter: ", modelFilter);
                var queryBase = query.aggregate([
                    { $match: modelFilter },
                    { $sort: { displayName: 1 } }
                ]);
                if (locationField != null) {
                    queryBase = query.aggregate([
                        locationField,
                        { $match: modelFilter },
                        { $sort: { displayName: 1 } }
                    ]);
                }
                console.log("query base is: ", queryBase);
                return queryBase.skip(skip).limit(limit);
            } }));
        return models;
    });
}
