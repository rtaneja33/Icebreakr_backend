"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express = require("express");
const services_1 = require("../../common/services");
const handlers_1 = require("./handlers");
const app = express();
exports.app = app;
services_1.initialApp(app);
app.use("/", handlers_1.router);
