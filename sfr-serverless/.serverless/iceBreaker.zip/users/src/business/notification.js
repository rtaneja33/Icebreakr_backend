"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("../../../common");
const serializers_1 = require("../serializers");
const user_1 = require("./user");
function parseMyNotification(ids, options) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const notifications = yield common_1.Notification.find({ _id: ids }).sort({ createdAt: -1 });
            const senderIds = notifications.map((e) => e.senderId);
            const userIds = notifications
                .filter((e) => e.type === common_1.ReferenceType.User)
                .map((e) => e.referenceId)
                .concat(senderIds);
            let users = [];
            let matches = [];
            if (userIds.length > 0) {
                users = yield common_1.User.find({ _id: userIds });
                users = yield user_1.parseProfiles(users);
            }
            return notifications.map((e) => {
                console.log("tt: ", users.find((u) => u._id.toString() === e.senderId.toString()));
                e.sender = users.find((u) => u._id.toString() === e.senderId.toString());
                if (e.type === common_1.ReferenceType.User && users.length > 0) {
                    e.reference = serializers_1.serializerUser(users.find((u) => u._id.toString() === e.referenceId.toString()));
                    return e;
                }
                if ((e.type === common_1.ReferenceType.Match || e.type === common_1.ReferenceType.Scorecard) && matches != null) {
                    // e.reference = match;
                    e.reference = matches.find((m) => m.matchInfo._id.toString() === e.referenceId.toString());
                    return e;
                }
                return e;
            });
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.parseMyNotification = parseMyNotification;
