"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("../../../common");
const models_1 = require("../models");
function emptyJson() {
    return {
        data: [],
        pagination: {
            total: 0,
            size: 0,
            totalPages: 0,
            page: 1,
            nextPageToken: null
        }
    };
}
exports.emptyJson = emptyJson;
function getFriendIdStringList(currentUserId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const myFriends = yield getMyFriendUserIdList(currentUserId);
            var friendIdList = [];
            if (myFriends != null && myFriends.length > 0) {
                for (var i = 0; i < myFriends.length; i++) {
                    var myFriendId = myFriends[i];
                    friendIdList.push(myFriendId.toString());
                }
            }
            return friendIdList;
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.getFriendIdStringList = getFriendIdStringList;
function getMyFriendUserIdList(currentUserId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let modelFilter = {
                status: common_1.StatusCode.Active,
                $or: [{ userId: currentUserId }, { friendUserId: currentUserId }],
                requestStatus: common_1.FriendRequestStatus.Accepted
            };
            const models = yield models_1.UserFriend.find(modelFilter);
            var myFriendIds = [];
            if (models != null && models.length > 0) {
                for (var i = 0; i < models.length; i++) {
                    let data = models[i];
                    if (data.userId.toString() === currentUserId.toString()) {
                        myFriendIds.push(data.friendUserId);
                    }
                    else if (data.friendUserId.toString() === currentUserId.toString()) {
                        myFriendIds.push(data.userId);
                    }
                }
            }
            console.log("My friend Ids: ", myFriendIds);
            return myFriendIds;
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.getMyFriendUserIdList = getMyFriendUserIdList;
function mySentFriendRequests(currentUserId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const mySentRequests = yield models_1.UserFriend.find({
                status: common_1.StatusCode.Active,
                userId: currentUserId,
                createdBy: currentUserId
            });
            var mySentRequestsList = [];
            if (mySentRequests != null && mySentRequests.length > 0) {
                for (var i = 0; i < mySentRequests.length; i++) {
                    var sentRequest = mySentRequests[i];
                    mySentRequestsList.push(sentRequest.friendUserId.toString());
                }
            }
            console.log("mySentRequestsList", mySentRequestsList);
            return mySentRequestsList;
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.mySentFriendRequests = mySentFriendRequests;
function hasSentMeFriendRequests(currentUserId) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const receivedRequests = yield models_1.UserFriend.find({
                status: common_1.StatusCode.Active,
                friendUserId: currentUserId,
                requestStatus: common_1.FriendRequestStatus.Sent,
            });
            var receivedRequestsList = [];
            if (receivedRequests != null && receivedRequests.length > 0) {
                for (var i = 0; i < receivedRequests.length; i++) {
                    var receivedRequest = receivedRequests[i];
                    receivedRequestsList.push(receivedRequest.userId.toString());
                }
            }
            console.log("receivedRequests", receivedRequestsList);
            return receivedRequestsList;
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.hasSentMeFriendRequests = hasSentMeFriendRequests;
function parseProfiles(users) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return users.map((e) => (Object.assign({}, e.toJSON ? e.toJSON() : e)));
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.parseProfiles = parseProfiles;
function parseUserProfile(user) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return user.toJSON ? user.toJSON() : user;
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.parseUserProfile = parseUserProfile;
