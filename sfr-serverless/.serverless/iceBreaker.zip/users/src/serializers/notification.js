"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("../../../common");
function serializerNotificationItem(model) {
    return {
        id: model._id,
        type: model.type,
        sender: common_1.serializeSimpleUser(model.sender),
        reference: model.reference,
        createdAt: model.createdAt,
        title: model.title,
        referenceId: model.referenceId,
        metadata: model.metadata,
        content: model.content,
    };
}
exports.serializerNotificationItem = serializerNotificationItem;
