"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function serializerUser(model) {
    return {
        id: model._id,
        avatar: model.avatar,
        companyName: model.companyName,
        jobTitle: model.jobTitle,
        alumnusStatus: model.alumnusStatus,
        currentAttendingSchool: model.currentAttendingSchool,
        alumnusOfSchool: model.alumnusOfSchool,
        cityOfOrigin: model.cityOfOrigin,
        phone: model.phone,
        phoneVerified: model.phoneVerified,
        displayName: model.displayName,
        email: model.email,
        country: model.country,
        location: model.location,
        provider: model.provider,
        deviceToken: model.deviceToken,
        deviceType: model.deviceType,
        calcDistance: model.calcDistance,
        socialInfo: model.socialInfo,
        numFriends: model.numFriends,
        isMyFriend: model.isMyFriend,
        role: model.role,
        searchRadius: model.searchRadius,
        friendRequestSent: model.friendRequestSent,
        friendRequestReceived: model.friendRequestReceived
    };
}
exports.serializerUser = serializerUser;
