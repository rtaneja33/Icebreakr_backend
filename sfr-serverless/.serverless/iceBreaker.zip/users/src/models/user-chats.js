"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("../../../common");
exports.UserChatSchemaName = "user_chats";
const UserChatSchema = new mongoose.Schema(common_1.SchemaBase({
    toUserId: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true
    },
    message: String
}), { timestamps: true });
exports.UserChat = mongoose.model(exports.UserChatSchemaName, UserChatSchema);
