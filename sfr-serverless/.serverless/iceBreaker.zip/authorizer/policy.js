"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Help function to generate an IAM policy
function generatePolicy(principalId, effect, resource) {
    // Required output:
    const authResponse = {
        principalId
    };
    if (effect && resource) {
        const policyDocument = {
            Version: "2012-10-17",
            Statement: [{
                    Action: "execute-api:Invoke",
                    Effect: effect,
                    Resource: resource,
                }]
        };
        authResponse.policyDocument = policyDocument;
    }
    return authResponse;
}
function generateAllow(principalId, resource) {
    return generatePolicy(principalId, "Allow", resource);
}
exports.generateAllow = generateAllow;
function generateDeny(principalId, resource) {
    return generatePolicy(principalId, "Deny", resource);
}
exports.generateDeny = generateDeny;
