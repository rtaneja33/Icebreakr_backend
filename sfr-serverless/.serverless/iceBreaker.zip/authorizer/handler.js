"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("../common");
const services_1 = require("../common/services");
const policy_1 = require("./policy");
function authorize(event, context) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const token = event.authorizationToken;
            const authId = yield common_1.verifyFirebaseToken(token);
            console.log("Authorize: ", authId);
            if (!authId) {
                const message = "Invalid token";
                console.warn(message);
                return context.fail("Unauthorized Check");
            }
            yield services_1.initDBConnection();
            const user = yield common_1.User.findOne({ authId });
            if (!user) {
                const message = `Can not find user with firebase ID: ${authId}`;
                console.warn(message);
                return context.fail("Unauthorized invalid");
            }
            // if (user.status !== StatusCode.Active) {
            //   const message = `User is ${user.status}`;
            //   console.warn(message);
            //   return context.fail("Unauthorized");
            // }
            const model = common_1.skipValueObject(user.toJSON());
            Object.keys(model).forEach((e) => {
                if (e === "_id") {
                    model[e] = model[e];
                }
                else if (Array.isArray(model[e])) {
                    model[e] = model[e].join(",");
                }
                else if (typeof model[e] === "object") {
                    model[e] = JSON.stringify(model[e]);
                }
            });
            const response = Object.assign({}, policy_1.generateAllow(context.awsRequestId, event.methodArn), { context: model });
            console.log("User authorized", model);
            return context.succeed(response);
        }
        catch (e) {
            console.log("Exception authorizer", e);
            return context.fail("Unauthorized");
        }
    });
}
exports.authorize = authorize;
function authorization(event, context) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const token = event.authorizationToken;
            const authId = yield common_1.verifyFirebaseToken(token);
            if (!authId) {
                const message = "Invalid token";
                console.warn(message);
                return context.fail("Unauthorized User");
            }
            const response = Object.assign({}, policy_1.generateAllow(context.awsRequestId, event.methodArn), { context: { authId } });
            console.log("User authorized", authId);
            return context.succeed(response);
        }
        catch (e) {
            console.log("Exception authorizer", e);
            return context.fail("Unauthorized");
        }
    });
}
exports.authorization = authorization;
