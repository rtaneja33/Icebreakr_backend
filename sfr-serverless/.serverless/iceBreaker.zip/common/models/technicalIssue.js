"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
exports.TechnicalIssuesSchemaName = "technical_issues";
const TechnicalIssuesSchema = new mongoose.Schema(common_1.SchemaBase({
    issue: String
}), { timestamps: true });
exports.TechnicalIssue = mongoose.model(exports.TechnicalIssuesSchemaName, TechnicalIssuesSchema);
