"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
var LikeStatus;
(function (LikeStatus) {
    LikeStatus["LIKED"] = "liked";
    LikeStatus["DISLIKED"] = "disliked";
})(LikeStatus = exports.LikeStatus || (exports.LikeStatus = {}));
var MatchStatus;
(function (MatchStatus) {
    MatchStatus["MATCHED"] = "matched";
    MatchStatus["UNMATCHED"] = "unmatched";
})(MatchStatus = exports.MatchStatus || (exports.MatchStatus = {}));
exports.UserActivitySchemaName = "user_activities";
const UserActivitySchema = new mongoose.Schema(common_1.SchemaBase({
    activityType: {
        type: String,
    },
    affectedUser: {
        type: mongoose.SchemaTypes.ObjectId,
    },
    isSurfBuddy: Boolean,
    reason: String,
    likeStatus: String,
    matchStatus: String,
    freeCupidCreatedAt: String,
    surfSpent: Number,
    nearBy: Boolean
}), { timestamps: true });
exports.UserActivity = mongoose.model(exports.UserActivitySchemaName, UserActivitySchema);
