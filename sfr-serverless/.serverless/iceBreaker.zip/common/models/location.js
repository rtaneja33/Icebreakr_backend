"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
const user_1 = require("./user");
exports.LocationSchemaName = "locations";
var LocationType;
(function (LocationType) {
    LocationType["POINT"] = "Point";
})(LocationType = exports.LocationType || (exports.LocationType = {}));
const LocationSchema = new mongoose.Schema(common_1.SchemaBase({
    referenceId: {
        required: true,
        type: mongoose.SchemaTypes.ObjectId,
        ref: user_1.UserSchemaName
    },
    location: Object
}), {
    timestamps: true
});
//LocationSchema.index({ referenceId: 1, createdBy: 1, type: 1 }, { unique: true });
exports.UserLocation = mongoose.model(exports.LocationSchemaName, LocationSchema);
