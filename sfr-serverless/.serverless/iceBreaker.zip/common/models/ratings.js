"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
const user_1 = require("./user");
exports.RatingSchemaName = "ratings";
const RatingSchema = new mongoose.Schema(common_1.SchemaBase({
    referenceId: {
        required: true,
        type: mongoose.SchemaTypes.ObjectId,
        ref: user_1.UserSchemaName
    },
    ratings: {
        required: true,
        type: Number
    },
    review: String
}), {
    timestamps: true
});
exports.Rating = mongoose.model(exports.RatingSchemaName, RatingSchema);
