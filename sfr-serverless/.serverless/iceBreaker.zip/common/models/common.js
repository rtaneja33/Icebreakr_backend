"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const UserSchemaName = "users";
var StatusCode;
(function (StatusCode) {
    StatusCode["Active"] = "active";
    StatusCode["Suspended"] = "suspended";
    StatusCode["Deleted"] = "deleted";
    StatusCode["Deactivated"] = "deactivated";
})(StatusCode = exports.StatusCode || (exports.StatusCode = {}));
var FriendRequestStatus;
(function (FriendRequestStatus) {
    FriendRequestStatus["Sent"] = "sent";
    FriendRequestStatus["Pending_Approval"] = "pending approval";
    FriendRequestStatus["Accepted"] = "accepted";
    FriendRequestStatus["Declined"] = "declined";
})(FriendRequestStatus = exports.FriendRequestStatus || (exports.FriendRequestStatus = {}));
function SchemaBase(schema) {
    const defaultSchema = {
        status: {
            type: String,
            required: true,
            default: StatusCode.Active
        },
        createdBy: {
            type: mongoose_1.SchemaTypes.ObjectId,
            ref: UserSchemaName
        },
        updatedBy: {
            type: mongoose_1.SchemaTypes.ObjectId,
            ref: UserSchemaName
        }
    };
    return Object.assign({}, schema, defaultSchema);
}
exports.SchemaBase = SchemaBase;
