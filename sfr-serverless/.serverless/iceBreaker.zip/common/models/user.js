"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
var Gender;
(function (Gender) {
    Gender["Male"] = "Male";
    Gender["Female"] = "Female";
})(Gender = exports.Gender || (exports.Gender = {}));
var Role;
(function (Role) {
    Role["Admin"] = "Admin";
    Role["User"] = "User";
})(Role = exports.Role || (exports.Role = {}));
var Provider;
(function (Provider) {
    Provider["Facebook"] = "facebook";
    Provider["LinkedIn"] = "linkedIN";
    Provider["Email"] = "email";
    Provider["Phone"] = "phone";
})(Provider = exports.Provider || (exports.Provider = {}));
var Subscription;
(function (Subscription) {
    Subscription["FREE"] = "free";
    Subscription["SURF_UNLIMTED"] = "unlimited";
})(Subscription = exports.Subscription || (exports.Subscription = {}));
var SurfProfile;
(function (SurfProfile) {
    SurfProfile["SURFDATE"] = "surfDate";
    SurfProfile["SURFBUDDY"] = "surfBuddy";
})(SurfProfile = exports.SurfProfile || (exports.SurfProfile = {}));
var AlumnusStatus;
(function (AlumnusStatus) {
    AlumnusStatus["AlumnusOf"] = "Alumnus of";
    AlumnusStatus["CurrentlyAttending"] = "Currently Attending";
})(AlumnusStatus = exports.AlumnusStatus || (exports.AlumnusStatus = {}));
exports.UserSchemaName = "users";
const UserSchema = new mongoose.Schema(common_1.SchemaBase({
    authId: {
        type: String,
        required: true,
        unique: true
    },
    avatar: String,
    companyName: String,
    jobTitle: String,
    alumnusStatus: String,
    currentAttendingSchool: String,
    alumnusOfSchool: String,
    cityOfOrigin: String,
    phone: Object,
    phoneVerified: Boolean,
    displayName: String,
    email: String,
    country: String,
    searchRadius: Number,
    location: Object,
    deviceToken: String,
    deviceType: String,
    socialInfo: Object,
    role: String,
    permissions: {
        type: [String],
        default: []
    },
    numFriends: Number,
    provider: {
        type: String,
        default: Provider.Phone
    }
}), {
    timestamps: true
});
exports.User = mongoose.model(exports.UserSchemaName, UserSchema);
function getNameUser(model) {
    let name = model.displayName;
    if (name.length > 20) {
        name = name.slice(0, 20) + "...";
    }
    return name;
}
exports.getNameUser = getNameUser;
