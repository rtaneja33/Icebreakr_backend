"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
exports.UserSuggestionsSchemaName = "user_suggestions";
const UserSuggestionSchema = new mongoose.Schema(common_1.SchemaBase({
    suggestions: String
}), { timestamps: true });
exports.UserSuggestion = mongoose.model(exports.UserSuggestionsSchemaName, UserSuggestionSchema);
