"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const helpers_1 = require("../helpers");
exports.PAGE_SIZE = 20;
const PREFIX_NEXT_PAGE_TOKEN = "Next_Page_Token";
function parsePaginationParams(input) {
    input = Object.assign({}, input);
    const result = {
        page: helpers_1.safeParseInt(input.page, 1),
        size: helpers_1.safeParseInt(input.size, exports.PAGE_SIZE),
        sort: input.sort || null,
        buildQuery: input.buildQuery || null,
        buildQueryCount: input.buildQueryCount || null
    };
    if (input.nextPageToken) {
        result.page = decodeNextPage(input.nextPageToken) + 1;
    }
    return result;
}
exports.parsePaginationParams = parsePaginationParams;
function parseSort(fields) {
    if (!fields || fields.length === 0) {
        return {};
    }
    const data = fields.map(e => {
        const executeRegex = /[^A-Za-z0-9\s]/g.exec(e);
        const orderBy = executeRegex && executeRegex.length > 0 ? executeRegex[0] : "";
        const key = e.replace(orderBy, "");
        return { [key]: orderBy === "-" ? -1 : 1 };
    });
    const result = {};
    data.forEach(e => {
        const firstKey = Object.keys(e)[0];
        result[firstKey] = e[firstKey];
    });
    return result;
}
exports.parseSort = parseSort;
function filterAll(modelClass, queryParams, pagingParams) {
    return __awaiter(this, void 0, void 0, function* () {
        const query = modelClass.find(queryParams);
        if (pagingParams && pagingParams.sort) {
            query.sort(pagingParams.sort);
        }
        const data = yield query.exec();
        return {
            data,
            pagination: {
                total: data.length,
                size: data.length,
                totalPages: 1,
                page: 1,
                nextPageToken: null
            }
        };
    });
}
exports.filterAll = filterAll;
function filterPagination(modelClass, queryParams = {}, pagingParams) {
    return __awaiter(this, void 0, void 0, function* () {
        const isNeedCountTotalPage = !pagingParams.nextPageToken
            && pagingParams.page;
        pagingParams = parsePaginationParams(pagingParams);
        if (!pagingParams || !pagingParams.page && !pagingParams.size) {
            return filterAll(modelClass, queryParams, pagingParams);
        }
        const page = (pagingParams && pagingParams.page) ? helpers_1.safeParseInt(pagingParams.page, 1) : 1;
        const options = Object.assign({ skip: 0 }, pagingParams, { page: page > 1 ? page : 1, limit: (pagingParams && pagingParams.size) ? helpers_1.safeParseInt(pagingParams.size, exports.PAGE_SIZE) : exports.PAGE_SIZE });
        options.skip = options.skip || ((options.page - 1) * options.limit);
        let count;
        let query;
        if (isNeedCountTotalPage) {
            if (pagingParams.buildQueryCount) {
                query = options.buildQueryCount(modelClass);
                count = yield query.exec();
            }
            else {
                count = yield modelClass.countDocuments(queryParams);
            }
        }
        if (pagingParams.buildQuery) {
            query = options.buildQuery(modelClass, options.limit, options.skip);
        }
        else {
            query = modelClass.find(queryParams).skip(options.skip).limit(options.limit);
            if (pagingParams.sort) {
                query.sort(pagingParams.sort);
            }
        }
        const results = yield query.exec();
        let totalPages;
        if (count) {
            totalPages = count % options.limit === 0
                ? count / options.limit
                : Math.floor(count / options.limit) + 1;
        }
        if (results.length === 0) {
            return {
                data: [],
                pagination: {
                    total: count || results.length,
                    size: options.limit,
                    totalPages: totalPages || 0,
                    page: options.page || 1,
                    nextPageToken: null
                }
            };
        }
        return {
            data: results,
            pagination: {
                totalPages,
                page: options.page || 1,
                total: count || results.length,
                size: options.limit,
                nextPageToken: results.length && results.length === options.size ?
                    encodeNextPage(PREFIX_NEXT_PAGE_TOKEN, options.page) : null
            }
        };
    });
}
exports.filterPagination = filterPagination;
function encodeNextPage(name, page) {
    return Buffer.from(name + page.toString()).toString("base64");
}
exports.encodeNextPage = encodeNextPage;
function decodeNextPage(hash) {
    return helpers_1.safeParseInt(Buffer.from(hash, "base64")
        .toString("ascii")
        .replace(PREFIX_NEXT_PAGE_TOKEN, ""), 1);
}
exports.decodeNextPage = decodeNextPage;
