"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Action;
(function (Action) {
})(Action = exports.Action || (exports.Action = {}));
exports.ActionGroups = {};
var Permissions;
(function (Permissions) {
    Permissions["Admin"] = "admin";
    Permissions["User"] = "user";
})(Permissions = exports.Permissions || (exports.Permissions = {}));
