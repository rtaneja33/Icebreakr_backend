"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
exports.BillingIssuesSchemaName = "billing_issues";
const BillingIssuesSchema = new mongoose.Schema(common_1.SchemaBase({
    issue: String
}), { timestamps: true });
exports.BillingIssue = mongoose.model(exports.BillingIssuesSchemaName, BillingIssuesSchema);
