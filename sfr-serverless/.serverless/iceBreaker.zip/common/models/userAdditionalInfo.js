"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LookingForOptions;
(function (LookingForOptions) {
    LookingForOptions["NEW_FRIENDS"] = "new friends";
    LookingForOptions["MARRIAGE"] = "marriage";
    LookingForOptions["SERIOUS_RELATIONSHIP"] = "serious relationship";
    LookingForOptions["SHORT_TERM_RELATIONSHIP"] = "short term relationship";
    LookingForOptions["HOOK_UP"] = "hook up";
    LookingForOptions["OPEN_TO_ALL"] = "Open to all";
})(LookingForOptions = exports.LookingForOptions || (exports.LookingForOptions = {}));
var Options;
(function (Options) {
    Options["YES"] = "yes";
    Options["NO"] = "no";
    Options["DOESNOTMATTER"] = "nomatter";
})(Options = exports.Options || (exports.Options = {}));
var Ethnicity;
(function (Ethnicity) {
    Ethnicity["ASIAN"] = "Asian";
    Ethnicity["WHITE"] = "White";
    Ethnicity["BLACK"] = "Black";
    Ethnicity["LATIN"] = "Hispanic/Latin";
    Ethnicity["OTHER"] = "Other";
    Ethnicity["OPEN_TO_ALL"] = "Open to all";
})(Ethnicity = exports.Ethnicity || (exports.Ethnicity = {}));
var Education;
(function (Education) {
    Education["HIGH_SCHOOL"] = "High School";
    Education["UNDER_GRADUATE"] = "Under Graduate";
    Education["GRADUATE"] = "Graduate";
    Education["POST_GRADUATE"] = "Post - Graduate";
    Education["OPEN_TO_ALL"] = "Open to all";
})(Education = exports.Education || (exports.Education = {}));
var LookingFor;
(function (LookingFor) {
    LookingFor["MEN"] = "men";
    LookingFor["WOMEN"] = "women";
    LookingFor["BOTH"] = "both";
})(LookingFor = exports.LookingFor || (exports.LookingFor = {}));
var SunSign;
(function (SunSign) {
    SunSign["CAPRICORN"] = "capricorn";
    SunSign["AQUARIUS"] = "aquarius";
    SunSign["PISCES"] = "pisces";
    SunSign["ARIES"] = "aries";
    SunSign["TAURUS"] = "taurus";
    SunSign["GEMINI"] = "gemini";
    SunSign["CANCER"] = "cancer";
    SunSign["LEO"] = "leo";
    SunSign["VIRGO"] = "virgo";
    SunSign["LIBRA"] = "libra";
    SunSign["SCORPIO"] = "scorpio";
    SunSign["SAGITTARIUS"] = "sagittarius";
    SunSign["OPEN_TO_ALL"] = "Open to all";
})(SunSign = exports.SunSign || (exports.SunSign = {}));
