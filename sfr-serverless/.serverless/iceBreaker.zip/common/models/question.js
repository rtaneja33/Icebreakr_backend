"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
exports.UserQuestionSchemaName = "user_questions";
const UserQuestionSchema = new mongoose.Schema(common_1.SchemaBase({
    questions: String,
    email: String
}), { timestamps: true });
exports.UserQuestion = mongoose.model(exports.UserQuestionSchemaName, UserQuestionSchema);
