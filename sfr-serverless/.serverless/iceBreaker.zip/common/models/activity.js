"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
var ActivityType;
(function (ActivityType) {
    ActivityType["LOGIN"] = "login";
    ActivityType["LOGOUT"] = "logout";
    ActivityType["DELETE"] = "delete";
    ActivityType["DEACTIVATE"] = "deactivate";
    ActivityType["REACTIVATE"] = "reactivate";
    ActivityType["SIGNUP"] = "signup";
    ActivityType["BLOCK"] = "block";
    ActivityType["REPORT"] = "report";
})(ActivityType = exports.ActivityType || (exports.ActivityType = {}));
exports.AccountActivitySchemaName = "account_activities";
const AccountActivitySchema = new mongoose.Schema(common_1.SchemaBase({
    activityType: {
        type: String,
    },
    affectedUser: {
        type: mongoose.SchemaTypes.ObjectId,
    },
}), { timestamps: true });
exports.AccountActivity = mongoose.model(exports.AccountActivitySchemaName, AccountActivitySchema);
