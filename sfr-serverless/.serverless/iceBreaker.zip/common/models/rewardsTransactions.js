"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const common_1 = require("./common");
const user_1 = require("./user");
exports.UserRewardsSchemaName = "user_rewards";
const UserRewardsSchema = new mongoose.Schema(common_1.SchemaBase({
    rewardedUser: {
        required: true,
        type: mongoose.SchemaTypes.ObjectId,
        ref: user_1.UserSchemaName
    },
    rewardPoints: Number,
    binId: {
        required: true,
        type: mongoose.SchemaTypes.ObjectId
    }
}), { timestamps: true });
exports.UserRewards = mongoose.model(exports.UserRewardsSchemaName, UserRewardsSchema);
