"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto = require("crypto");
const ALGORITHM = "aes-128-ecb";
function encodeCipher(text, secret) {
    const cipher = crypto.createCipher(ALGORITHM, secret);
    let encrypted = cipher.update(text, "utf8", "hex");
    encrypted += cipher.final("hex");
    return encrypted;
}
exports.encodeCipher = encodeCipher;
function decodeCipher(hash, secret) {
    const decipher = crypto.createDecipher(ALGORITHM, secret);
    let decrypted = decipher.update(hash, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
}
exports.decodeCipher = decodeCipher;
