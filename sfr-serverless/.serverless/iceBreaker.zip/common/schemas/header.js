"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Joi = require("joi");
exports.HeaderAuthorizationSchema = Joi.object({
    authorization: Joi.string().required()
});
