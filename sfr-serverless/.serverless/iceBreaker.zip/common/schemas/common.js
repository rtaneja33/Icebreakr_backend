"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Joi = require("joi");
const models_1 = require("../models");
exports.StatusSchema = Joi.string().valid([
    models_1.StatusCode.Active, models_1.StatusCode.Deleted,
    models_1.StatusCode.Suspended
]);
