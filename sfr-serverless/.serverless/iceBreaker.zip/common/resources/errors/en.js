"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = require("./types");
exports.default = {
    [types_1.ErrorKey.ErrorUnknown]: "Unknown error",
    [types_1.ErrorKey.ProfileNotFound]: "Profile not found",
    [types_1.ErrorKey.EmailNotFound]: "Email not found",
    [types_1.ErrorKey.Unauthorized]: "Unauthorized user test",
    [types_1.ErrorKey.UsernameExisted]: "Username already exists",
    [types_1.ErrorKey.AuthExisted]: "Firebase Authorization is already existed",
    [types_1.ErrorKey.EmailExisted]: "Email already exists",
    [types_1.ErrorKey.IsAdmin]: "This action is forbidden",
    [types_1.ErrorKey.AllowForgotPassword]: "You are not able to reset password for this account, it has been used for Facebook login.",
    [types_1.ErrorKey.BinNotFound]: "Bin not found",
    [types_1.ErrorKey.BinIdNeeded]: "Bin Id needed",
    [types_1.ErrorKey.DeviceIdNeeded]: "Device Id needed",
    [types_1.ErrorKey.DeviceNotFound]: "Device not found",
    [types_1.ErrorKey.LatLongNeeded]: "Lat/long needed",
    [types_1.ErrorKey.PhoneExisted]: "Phone number already exists",
    [types_1.ErrorKey.InvalidFriendRequest]: "Invalid friend request",
    [types_1.ErrorKey.NotAFriend]: "The mentioned user is not a friend",
    [types_1.ErrorKey.SearchCoordinatesNeeded]: "Search Coordinates needed"
};
