"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const lodash = require("lodash");
const en_1 = require("./en");
__export(require("./types"));
function getTitleOfNotificationKey(key) {
    const notification = lodash.cloneDeep(en_1.default[key]);
    if (!notification) {
        return null;
    }
    else {
        return notification.title;
    }
}
exports.getTitleOfNotificationKey = getTitleOfNotificationKey;
function getContentNotification(key, opts = {}) {
    const notification = lodash.cloneDeep(en_1.default[key]);
    if (!notification) {
        console.log("Cannot find content notification with key " + key);
        return null;
    }
    console.log("Opt params: ", opts.params);
    console.log("Notification: ", notification);
    return opts.params ? parseContentNotification(notification, opts.params) : notification;
}
exports.getContentNotification = getContentNotification;
function parseContentNotification(notification, params) {
    const delimiterLeft = "{{";
    const delimiterRight = "}}";
    const keyParamsContent = Object.keys(params.content || {});
    const keyParamsTitle = Object.keys(params.title || {});
    console.log("keyParamsContent: ", keyParamsContent);
    console.log("keyParamsTitle: ", keyParamsTitle);
    if (keyParamsContent.length > 0) {
        keyParamsContent.forEach((e) => {
            notification.content = notification.content.replace(delimiterLeft + e + delimiterRight, params.content[e]);
        });
    }
    if (keyParamsTitle.length > 0) {
        keyParamsTitle.forEach((e) => {
            notification.title = notification.title.replace(delimiterLeft + e + delimiterRight, params.title[e]);
        });
    }
    console.log("Notification: ", notification);
    return notification;
}
exports.parseContentNotification = parseContentNotification;
