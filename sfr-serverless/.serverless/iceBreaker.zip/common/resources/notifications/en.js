"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = require("./types");
exports.default = {
    [types_1.NotificationKeyType.SentFriendRequest]: {
        title: "has sent you friend request"
    },
    [types_1.NotificationKeyType.AcceptedFriendRequest]: {
        title: "has accepted your friend request"
    },
    [types_1.NotificationKeyType.MatchPlay]: {
        title: "has invited you to play"
    },
    [types_1.NotificationKeyType.MatchPlayAccepted]: {
        title: "has accepted your invitation to play"
    },
    [types_1.NotificationKeyType.MatchPlayDeclined]: {
        title: "has declined your invitation to play"
    },
    [types_1.NotificationKeyType.MatchPlayRequested]: {
        title: "has requested to play"
    },
    [types_1.NotificationKeyType.MatchPlayRequestAccepted]: {
        title: "has accepted your request to play"
    },
    [types_1.NotificationKeyType.MatchPlayRequestDeclined]: {
        title: "has declined your request to play"
    },
    [types_1.NotificationKeyType.UploadScoreCard]: {
        title: "has uploaded the score card. Please review and accept the scores"
    },
    [types_1.NotificationKeyType.PlayerScoreCardUploaded]: {
        title: "has uploaded the player score. Please review and accept the scores for the player"
    },
    [types_1.NotificationKeyType.TeamScoreCardUploaded]: {
        title: "has uploaded the team score. Please review and accept the scores for the team"
    },
    [types_1.NotificationKeyType.MatchResultDeclared]: {
        title: "has declared the results for match"
    },
    [types_1.NotificationKeyType.MatchStarted]: {
        title: "has started the match"
    },
    [types_1.NotificationKeyType.MatchFinished]: {
        title: "has ended the match"
    },
    [types_1.NotificationKeyType.MatchApproved]: {
        title: "has approved the match"
    }
};
