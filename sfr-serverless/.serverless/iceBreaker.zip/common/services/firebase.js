"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const firebaseAdmin = require("firebase-admin");
let firebaseApp;
exports.firebaseApp = firebaseApp;
if (!firebaseApp) {
    exports.firebaseApp = firebaseApp = firebaseAdmin.initializeApp({
        credential: firebaseAdmin.credential.cert({
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY,
            projectId: process.env.FIREBASE_PROJECT_ID
        }),
        databaseURL: "https://dev-ice-breaker.firebaseio.com"
    });
}
