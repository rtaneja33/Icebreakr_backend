"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bodyParser = require("body-parser");
const cors = require("cors");
const middlewares_1 = require("../middlewares");
function initialApp(app) {
    // app.use(bodyParser.json());
    app.use(bodyParser.json({ limit: '5mb' }));
    app.use(cors({
        allowedHeaders: ["Content-Encoding", "Accept-Encoding"]
    }));
    app.use(middlewares_1.MongoMiddleware);
    app.use(middlewares_1.LoggerMiddleware);
    if (process.env.IS_OFFLINE) {
        app.use(middlewares_1.FakeAuthMiddleware);
    }
    app.use(middlewares_1.ErrorHandlerMiddleware);
}
exports.initialApp = initialApp;
