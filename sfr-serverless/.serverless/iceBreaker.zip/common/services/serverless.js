"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const serverless = require("serverless-http");
exports.serverlessHandler = (app) => serverless(app, {
    request(request, event) {
        request.context = Object.assign({}, request.context, { currentUser: event.requestContext.authorizer });
        if (event.httpMethod !== "GET" && event.body) {
            request.body = JSON.parse(event.body);
        }
    }
});
