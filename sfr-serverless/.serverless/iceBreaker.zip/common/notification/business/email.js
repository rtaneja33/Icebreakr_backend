"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const nodemailer = require("nodemailer");
const emails_1 = require("../emails");
const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_API_KEY);
function emailPusher() {
    if (!process.env.GMAIL_USER || !process.env.GMAIL_PASS) {
        return null;
    }
    console.log("ppppp", {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_PASS
    });
    return nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.GMAIL_USER,
            pass: process.env.GMAIL_PASS
        }
    });
}
exports.emailPusher = emailPusher;
function sendEmail(options, form) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // const pusher = emailPusher();
            const mailOptions = formatFormEmail(options, form);
            //if (!pusher || !mailOptions) { return null; }
            if (!mailOptions) {
                return null;
            }
            //return await pusher.sendMail(mailOptions);
            //return true;
            return yield sgMail.send(mailOptions);
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.sendEmail = sendEmail;
function formatFormEmail(options, form) {
    const data = emails_1.parseDataEmail(form);
    if (!data || !options.emailsReceive ||
        (Array.isArray(options.emailsReceive) && options.emailsReceive.length === 0)) {
        return null;
    }
    console.log({
        from: process.env.GMAIL_USER,
        to: options.emailsReceive,
        subject: data.emailSubjectTitle,
        html: data.emailBody
    });
    return {
        from: process.env.GMAIL_USER,
        to: options.emailsReceive,
        subject: data.emailSubjectTitle,
        html: data.emailBody
    };
}
exports.formatFormEmail = formatFormEmail;
