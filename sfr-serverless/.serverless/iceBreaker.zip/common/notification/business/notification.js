"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = require("lodash");
const moment = require("moment");
const helpers_1 = require("../../helpers");
const models_1 = require("../../models");
const models_2 = require("../models");
const vendors_1 = require("../vendors");
const one_signal_1 = require("../vendors/one-signal");
const notification_user_1 = require("./notification-user");
const business_1 = require("../../../users/src/business");
let _pusher;
function notificationPusher(appId, apiKey) {
    if (_pusher) {
        return _pusher;
    }
    appId = appId || process.env.ONE_SIGNAL_APP_ID;
    apiKey = apiKey || process.env.ONE_SIGNAL_API_KEY;
    _pusher = one_signal_1.OneSignalPusher(one_signal_1.OneSignalClient({
        app_id: appId,
        api_key: apiKey,
    }));
    console.log("appId: ", appId);
    console.log("api_key: ", apiKey);
    return _pusher;
}
exports.notificationPusher = notificationPusher;
function createNotification(input, options) {
    return __awaiter(this, void 0, void 0, function* () {
        const opts = Object.assign({}, options);
        const model = yield models_2.Notification.create(Object.assign({ senderId: opts.actorId, createdBy: opts.actorId || input.senderId, updatedBy: opts.actorId || input.senderId }, lodash_1.omit(input, ["receiverIds"])));
        const receivers = yield notification_user_1.createManyNotificationUsers(model.id, input.receiverIds, options);
        return Object.assign({}, model, { receivers });
    });
}
exports.createNotification = createNotification;
function createAndPushNotification(pusher, input, options) {
    return __awaiter(this, void 0, void 0, function* () {
        pusher = pusher || notificationPusher();
        input.content = input.content || input.title;
        const model = yield createNotification(input, options);
        const payload = vendors_1.validateNotificationForm(input, {
            formatParams: options.formatParams
        });
        yield pusher.sendToUsers(input.receiverIds, payload);
        return model;
    });
}
exports.createAndPushNotification = createAndPushNotification;
function createAndPushNotificationWithFormat(pusher, input, options) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            pusher = pusher || notificationPusher();
            console.log("Iput: ", input);
            console.log("receiverIds: ", input.receiverIds);
            console.log("options.actorId: ", options.actorId);
            const receiverIds = input.receiverIds
                .filter((e) => e.toString() !== options.actorId.toString());
            console.log("receiverIds: ", receiverIds);
            if (receiverIds.length === 0) {
                return null;
            }
            let user = yield models_1.User.findById(options.actorId);
            user = yield business_1.parseUserProfile(user);
            const model = yield createNotification(input, options);
            const payload = vendors_1.validateNotificationForm(input, {
                formatParams: (params) => {
                    console.log("Title: ", params);
                    var text = `${models_1.getNameUser(user)} ${params.title}`;
                    params.title = process.env.APP_NAME;
                    params.content = text;
                    return params;
                }
            });
            console.log("Payload: ", payload);
            const pushe = yield pusher.sendToUsers(receiverIds, payload);
            console.log("pushe: ", pushe);
            console.log("Model: ", model);
            return model;
        }
        catch (error) {
            console.log("Error string: ", {
                error
            });
            return null;
        }
    });
}
exports.createAndPushNotificationWithFormat = createAndPushNotificationWithFormat;
function pushNotificationBroadcast(pusher, input, options) {
    return __awaiter(this, void 0, void 0, function* () {
        pusher = pusher || notificationPusher();
        try {
            const user = yield models_1.User.findById(options.actorId);
            const notification = yield models_2.Notification.create(helpers_1.skipValueObject({
                content: input.title,
                senderId: input.senderId,
                metadata: {
                    url: input.content
                },
                type: input.type,
                expiryDate: moment(input.expiryDate).format(helpers_1.DEFAULT_DATE_FORMAT)
            }));
            yield models_2.NotificationUser.create({
                notificationId: notification._id,
                userId: null,
                isRead: false,
                typeRole: input.tags.map((e) => e.value)
            });
            const payload = vendors_1.validateNotificationForm(Object.assign({}, input, { url: input.content }), {
                formatParams: (params) => {
                    params.content = params.title;
                    params.title = models_1.getNameUser(user);
                    return params;
                }
            });
            yield pusher.broadcast(payload);
            return null;
        }
        catch (error) {
            console.log("Error string: ", {
                error
            });
            return null;
        }
    });
}
exports.pushNotificationBroadcast = pushNotificationBroadcast;
