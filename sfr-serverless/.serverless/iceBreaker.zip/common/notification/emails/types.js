"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EmailTemplateType;
(function (EmailTemplateType) {
    EmailTemplateType["NewUser"] = "new_user";
    EmailTemplateType["NewUserAdmin"] = "new_user_admin";
    EmailTemplateType["ApproveUserAdmin"] = "approve_user_admin";
    EmailTemplateType["ApproveUser"] = "approve_user";
    EmailTemplateType["RejectUserAdmin"] = "reject_user_admin";
    EmailTemplateType["RejectUser"] = "reject_user";
})(EmailTemplateType = exports.EmailTemplateType || (exports.EmailTemplateType = {}));
