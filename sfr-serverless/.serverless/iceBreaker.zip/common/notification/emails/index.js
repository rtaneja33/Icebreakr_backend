"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const lodash = require("lodash");
const templates_1 = require("./templates");
const types_1 = require("./types");
__export(require("./types"));
exports.emailTemplates = {
    [types_1.EmailTemplateType.NewUser.toString()]: {
        title: "Welcome to Lynksin-Golf",
        content: templates_1.newUserTemplate
    },
    [types_1.EmailTemplateType.NewUserAdmin.toString()]: {
        title: "Email inform about new user to admin users",
        content: templates_1.newUserAdminTemplate
    },
    [types_1.EmailTemplateType.ApproveUserAdmin.toString()]: {
        title: "Email inform about approval of user to admin users",
        content: templates_1.approveUserAdminTemplate
    },
    [types_1.EmailTemplateType.ApproveUser.toString()]: {
        title: "Lynksin-Golf User Approved",
        content: templates_1.approveUserTemplate
    },
    [types_1.EmailTemplateType.RejectUserAdmin.toString()]: {
        title: "Email inform about rejection of user to admin users",
        content: templates_1.rejectUserAdminTemplate
    },
    [types_1.EmailTemplateType.RejectUser.toString()]: {
        title: "Lynksin-Golf User Rejected",
        content: templates_1.rejectedUserTemplate
    }
};
function parseParam(params, text) {
    console.log("Object.keys(params)", Object.keys(params));
    if (params && Object.keys(params).length > 0) {
        Object.keys(params).forEach((e) => {
            text = text.replace(`{{${e}}}`, params[e]);
        });
    }
    return text;
}
exports.parseParam = parseParam;
function parseDataEmail(options) {
    const emailTemplate = lodash.cloneDeep(exports.emailTemplates[options.type]);
    if (!emailTemplate) {
        return null;
    }
    const keysEmailTemplate = Object.keys(emailTemplate);
    const paramsTemplate = options.params;
    if (paramsTemplate) {
        Object.keys(paramsTemplate).forEach((e) => {
            if (paramsTemplate[e] && keysEmailTemplate.includes(e)) {
                emailTemplate[e] = parseParam(paramsTemplate[e], emailTemplate[e]);
            }
        });
    }
    return {
        emailBody: emailTemplate.content,
        emailSubjectTitle: emailTemplate.title
    };
}
exports.parseDataEmail = parseDataEmail;
