"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const models_1 = require("../../models");
const notification_1 = require("./notification");
exports.NotificationUserSchemaName = "notification_users";
const NotificationUserSchema = new mongoose.Schema({
    notificationId: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: notification_1.NotificationSchemaName
    },
    userId: {
        type: mongoose.SchemaTypes.ObjectId,
        ref: models_1.UserSchemaName
    },
    isRead: {
        type: Boolean,
        default: false
    },
    isViewed: {
        type: Boolean,
        default: false
    },
    typeRole: [String]
}, {
    timestamps: true
});
exports.NotificationUser = mongoose.model(exports.NotificationUserSchemaName, NotificationUserSchema);
