"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const models_1 = require("../../models");
var ReferenceType;
(function (ReferenceType) {
    ReferenceType["User"] = "user";
    ReferenceType["Match"] = "match";
    ReferenceType["Scorecard"] = "scorecard";
})(ReferenceType = exports.ReferenceType || (exports.ReferenceType = {}));
exports.NotificationSchemaName = "notifications";
const NotificationSchema = new mongoose.Schema(models_1.SchemaBase({
    title: String,
    content: String,
    senderId: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true
    },
    metadata: Object,
    type: {
        type: String,
        require: true
    },
    referenceId: mongoose.SchemaTypes.ObjectId,
    referenceUrl: String,
    expiryDate: Date
}), {
    timestamps: true
});
exports.Notification = mongoose.model(exports.NotificationSchemaName, NotificationSchema);
