"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const firebaseAdmin = require("firebase-admin");
const services_1 = require("../services");
const middleware_1 = require("./middleware");
function createFirebaseUser(form) {
    // create firebase user
    return services_1.firebaseApp.auth()
        .createUser({
        email: form.email,
        password: form.password,
        emailVerified: form.emailVerified || false
    });
}
exports.createFirebaseUser = createFirebaseUser;
function deleteFirebaseUser(uid) {
    // delete user firebase
    return services_1.firebaseApp.auth().deleteUser(uid);
}
exports.deleteFirebaseUser = deleteFirebaseUser;
function getUserFirebaseByEmail(email) {
    // get user firebase by email
    return services_1.firebaseApp.auth().getUserByEmail(email);
}
exports.getUserFirebaseByEmail = getUserFirebaseByEmail;
// update information of user, but create this function to update password for user
function updateUserFirebaseByAuthId(authId, form) {
    return services_1.firebaseApp.auth().updateUser(authId, form);
}
exports.updateUserFirebaseByAuthId = updateUserFirebaseByAuthId;
function verifyFirebaseToken(token) {
    return services_1.firebaseApp.auth()
        .verifyIdToken(token)
        .then((user) => {
        return user.uid;
    }).catch((error) => Promise.reject(error));
}
exports.verifyFirebaseToken = verifyFirebaseToken;
function firebaseAuthMiddleware(authId) {
    return middleware_1.privateMiddleware(authId || verifyFirebaseToken);
}
exports.firebaseAuthMiddleware = firebaseAuthMiddleware;
function deleteAllFirebaseUser() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const listUsersResult = yield services_1.firebaseApp.auth().listUsers(10);
            yield Promise.all(listUsersResult.users.map((e) => services_1.firebaseApp.auth().deleteUser(e.uid)));
            return null;
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.deleteAllFirebaseUser = deleteAllFirebaseUser;
function getFirebaseUserByIds(uids) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return yield Promise.all(uids.map((e) => __awaiter(this, void 0, void 0, function* () {
                try {
                    return yield services_1.firebaseApp.auth().getUser(e);
                }
                catch (error) {
                    return null;
                }
            })));
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.getFirebaseUserByIds = getFirebaseUserByIds;
function getFirebaseUserById(uid) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return services_1.firebaseApp.auth().getUser(uid);
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.getFirebaseUserById = getFirebaseUserById;
function listUsersFirebase(pageSize, pageToken) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            pageSize = pageSize ? parseInt(pageSize, 0) : 100;
            return yield services_1.firebaseApp.auth().listUsers(pageSize, pageToken);
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.listUsersFirebase = listUsersFirebase;
function pushMatchNotification(registrationToken, payload, options) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return yield firebaseAdmin.messaging().sendToDevice(registrationToken, payload, options);
        }
        catch (error) {
            return Promise.reject(error);
        }
    });
}
exports.pushMatchNotification = pushMatchNotification;
