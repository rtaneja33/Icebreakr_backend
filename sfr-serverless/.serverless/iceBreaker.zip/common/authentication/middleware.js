"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("../models");
// authentication
function privateMiddleware(verify, options) {
    const { authIdKey = "authId" } = Object.assign({}, options);
    return (req, res, next) => __awaiter(this, void 0, void 0, function* () {
        if (req.method.toLowerCase() === "options") {
            return next();
        }
        const token = req.header("Authorization");
        if (!token) {
            console.log("Authorization header is required");
            return res.status(401).send({
                message: "Authorization header is required"
            });
        }
        try {
            const uid = typeof verify === "function" ? yield verify(token) : verify;
            const user = yield models_1.User.findOne({ [authIdKey]: uid });
            if (!user) {
                const message = `Can not find user with firebase ID: ${uid}`;
                console.log(message);
                return res.status(401).send({
                    message
                });
            }
            if (user.status !== models_1.StatusCode.Active) {
                const message = `User is ${user.status}`;
                console.log(message);
                return res.status(401).send({ message });
            }
            req.context.currentUser = user;
            console.log("Log request:");
            console.log("Url: " + req.originalUrl);
            console.log("Method: " + req.method);
            console.log("Headers: " + JSON.stringify(req.headers, null, 2));
            console.log("Payload: " + JSON.stringify({
                body: req.body,
                params: req.params,
                query: req.query
            }, null, 2));
            return next();
        }
        catch (e) {
            if (!e.statusCode || e.statusCode !== 401) {
                console.error("Authorize error:", e);
            }
            console.log(e.message);
            return res.status(e.statusCode || 401).send(e || {
                message: "Unauthorized"
            });
        }
    });
}
exports.privateMiddleware = privateMiddleware;
