"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function ErrorHandlerMiddleware(error, _req, res, next) {
    if (error) {
        console.error(error);
        return res.status(500).json({
            code: "internal",
            message: error.message,
            debugMessage: error.stack
        });
    }
    return next();
}
exports.ErrorHandlerMiddleware = ErrorHandlerMiddleware;
