"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = require("joi");
const helpers_1 = require("../helpers");
// validate
function commonValidator(schema, key, options) {
    return (req, res, next) => {
        const value = req[key];
        return joi_1.validate(value, schema, options).then(() => {
            return next();
        }).catch((errors) => {
            const firstError = errors.details[0];
            const error = {
                code: firstError.type,
                message: firstError.message
            };
            return helpers_1.responseError(req, res, error);
        });
    };
}
function validateParams(schema, options) {
    return commonValidator(schema, "params", options);
}
exports.validateParams = validateParams;
function validateBody(schema, options) {
    return commonValidator(schema, "body", options);
}
exports.validateBody = validateBody;
function validateQuery(schema, options) {
    return commonValidator(schema, "query", options);
}
exports.validateQuery = validateQuery;
function validateHeader(schema, options) {
    return commonValidator(schema, "headers", options);
}
exports.validateHeader = validateHeader;
