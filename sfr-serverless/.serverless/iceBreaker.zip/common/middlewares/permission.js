"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const helpers_1 = require("../helpers");
const models_1 = require("../models");
const resources_1 = require("../resources");
function isAdmin(req, res, next) {
    const currentUser = req.context.currentUser;
    if (!currentUser) {
        return helpers_1.responseError(req, res, resources_1.ErrorKey.ProfileNotFound, {
            statusCode: 401
        });
    }
    let permissions = currentUser.permissions;
    if (!Array.isArray(permissions)) {
        permissions = permissions ? permissions.split(",") : [];
    }
    if (permissions.includes(models_1.Permissions.Admin)) {
        return next();
    }
    return helpers_1.responseError(req, res, resources_1.ErrorKey.IsAdmin, {
        statusCode: 401
    });
}
exports.isAdmin = isAdmin;
