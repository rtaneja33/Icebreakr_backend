"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("../models");
// testsfr@gmail.com
exports.EmailFakeAuth = "tranvannhut4495@gmail.com";
function FakeAuthMiddleware(req, _res, next) {
    const emailFakeAuthFromHeader = req.headers.emailFakeAuth;
    const email = emailFakeAuthFromHeader || process.env.EMAIL_FAKE_AUTH || exports.EmailFakeAuth;
    const userInput = {
        email,
        authId: "aPyje3yeo2UGasdasIYbzP7KBo8wFl5x1",
        username: "testsfr",
        firstName: "Test",
        lastName: "iceBreaker",
        country: "US",
        status: models_1.StatusCode.Active,
        permissions: [models_1.Permissions.Admin]
    };
    return models_1.User.findOne({ email, status: models_1.StatusCode.Active })
        .then((u) => u || models_1.User.create(userInput))
        .then((u) => {
        req.context = req.context || {};
        req.context.currentUser = u;
        next();
    }).catch(next);
}
exports.FakeAuthMiddleware = FakeAuthMiddleware;
