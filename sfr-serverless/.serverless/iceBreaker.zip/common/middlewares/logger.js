"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function LoggerMiddleware(req, _res, next) {
    if (process.env.NODE_ENV && process.env.NODE_ENV === "unit_test") {
        return next();
    }
    console.log("--------------------------- Log request ---------------------------");
    parseLogger(req, _res);
    return next();
}
exports.LoggerMiddleware = LoggerMiddleware;
function parseLogger(req, _res) {
    console.log("Url: " + req.url);
    console.log("Method: " + req.method);
    console.log("Headers: " + JSON.stringify(req.headers, null, 2));
    console.log("Payload: " + JSON.stringify({
        body: req.body,
        params: req.params,
        query: req.query
    }, null, 2));
}
exports.parseLogger = parseLogger;
