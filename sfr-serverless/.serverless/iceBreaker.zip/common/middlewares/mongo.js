"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const services_1 = require("../services");
function MongoMiddleware(_req, _res, next) {
    return services_1.initDBConnection()
        .then((_) => next()).catch(next);
}
exports.MongoMiddleware = MongoMiddleware;
